
LANGUAGE = {
	["CraftMissingFlag"] = "You are missing the %s flag.",
	["CraftMissingTool"] = "You are missing a %s.",
	["CraftMissingItem"] = "You are missing: %s.",
	["CraftSuccess"] = "You have successfully crafted %s.",

	["CraftTools"] = "TOOLS",
	["CraftRequirements"] = "REQUIREMENTS",
	["CraftResults"] = "RESULTS",

	["cmdCraftRecipe"] = "Attempt to craft a recipe.",

	["noWorkbench"] = "You need to be near a workbench.",

	stationWorkbenchDesc = "A workbench used for crafting.",

	recipeManhackDesc = "Assemble some parts to craft a Manhack.",
	recipeScannerDesc = "Assemble some parts to craft a Combine Scanner.",
	recipeWaterDesc = "Mix somethings into a Breen's Water.",
}
