
STATION.name = "Workbench"
STATION.description = "stationWorkbenchDesc"
STATION.model = "models/props_wasteland/controlroom_desk001b.mdl"
